# Hematoloji 100 Soru Etkileşimli Test

Bu proje, 100 adet hematoloji sorusunu içeren etkileşimli bir HTML testidir.

## Kullanım
1. Dosyayı GitHub deposuna yükleyin (örnek: `hematoloji-test`).
2. **Settings → Pages** sekmesinden `main` branch'ini seçin ve kaydedin.
3. 1 dakika içinde bağlantı şu şekilde aktif olur:
   ```
   https://<kullaniciadi>.github.io/hematoloji-test/
   ```
4. Tarayıcıda açtığınızda test etkileşimli olarak çalışacaktır.

---
Hazırlayan: ChatGPT (GPT-5)
